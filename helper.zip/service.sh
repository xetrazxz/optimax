#!/system/bin/sh

# Wait 15 Seconds
sleep 1
