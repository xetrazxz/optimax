#### Optimax
### XiaoMeme Tweaks
*** Android 13 + AOSP/HyperOS/MIUi

##

- CPU Tweak
- Dexopt
- SurfaceFlinger Color Control 
- Auto-config fetch by device codename
- Lightweight

## WebUI Access

Requires KernelSU(N) / Apatch support.

## Installation
1. Download and Flash Optimax And Optimax Helper From Releases
2. Reboot 
3. Open KernelSU(N) / Apatch Manager
4. Go to Modules → Optimax → WebUI
5. Interface will launch in the embedded browser

## Device Support
** For Adding Your Device Config
- Send Phone Available CPU Policy clock Speeds and Available CPU governers Here to [Telegram](https://t.me/+UceVylCgLSoyMmNl)
-Format
-
-CodeName
-PolicyX - Clock Speed 1 2 3 . . . . 
-PolicyY - Clock Speed 1 2 3 . . . . 
-Available CPU Governer 



